/*
 ============================================================================
 Name        : GameOfLifeMPI.c
 Author      : Michael Schmidt
 Version     : 3
 Copyright   :
 Description : Game Of Life MPI
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <mpi.h>

	static int generations = 0; // Hold the number of generations
	static int rows = 0; // Hold the number of rows for the game board
	static int cols = 0; // Hold the number of columns for the game board

	// checker board from text file
	char* configFileName;

	//checker board variables
	static int *currentOneDimensionalCheckerBoard;
	static int *newOneDimensionalCheckerBoard;

	// MPI variables
	int number_of_processes;
	int identity;

	// Stucture to hold the data sent to the MPI process
	struct life_t {
		int  startRow;
		int  endRow;
	};

	//gets spot on the board
	static int getIndex(int row, int col) {
		return row * cols + col;
	}

	//prints the one dimensional checker board as a two dimensional checker board.
	//prints with *'s and .'s
	static void printOneDimensionalBoard(int oneDimensionalCheckerBoard[]) {
		int row = 0;
		int col = 0;
		for (row = 0; row < rows; row++) {
			for (col = 0; col < cols; col++) {
				if (0 == oneDimensionalCheckerBoard[/*GameOfLife.*/getIndex(row,col)])
					printf(".");
				else
					printf("*");
			}
			printf("\n");
		}
		printf("\n");
	}

	//Loads the file from load configurations
	//Can be changed by changing the arguments in run configurations
	static void loadConfiguration(char* fileName) {
		configFileName = fileName;

		FILE * file = fopen (fileName, "r");

		//check if file can be opened
		if (file == NULL)
		{
			printf("%s does not exist or cannot be opened\n", fileName);
			return;
		}
			//iterations
			fscanf(file, "%d", &generations);

			printf("Generations: %d\n", generations);

			//columns
			fscanf(file, "%d", &cols);
			printf("cols %d\n", cols);


			//rows
			fscanf(file, "%d", &rows);
			printf("rows %d\n", rows);

			//checkerboards
			currentOneDimensionalCheckerBoard = malloc(sizeof (int) * rows * cols);
			newOneDimensionalCheckerBoard     = malloc(sizeof (int) * rows * cols);


			//reads in the values for the checker board
			int row = 0;
			int col = 0;
			for (row = 0; row < rows; row++) {
				for (col = 0; col < cols; col++) {

					fscanf(file, "%d", &(currentOneDimensionalCheckerBoard[getIndex(row,col)]));
					newOneDimensionalCheckerBoard[getIndex(row, col)] =
					currentOneDimensionalCheckerBoard[getIndex(row, col)];
					printf("%d ", currentOneDimensionalCheckerBoard[getIndex(row, col)]);
				}
				printf("\n");
			}
	}

	//checks to see if the cell is in range of the checker board
	static bool inRange(int row, int col) {
		if (row >= 0 && row < rows && col >= 0 && col < cols){
		return true;
		}else{
		return false;
		}
	}

	//checks to see if a cell is alive or dead
	static int isAlive(int row, int col) {
		int cellLife = 0;

		if (inRange(row, col)) {
			cellLife = currentOneDimensionalCheckerBoard[getIndex(row, col)];
		}

		return cellLife;
	}

	//counts the number of live neighbors from the current cell.
	static int countLiveNeighbors(int row, int col) {
		int numberOfLiveNeighbors = 0;

		int minRow = row - 1;
		int maxRow = row + 1;
		int minCol = col - 1;
		int maxCol = col + 1;

		int currentRow = 0;
		int currentCol = 0;
		for (currentRow = minRow; currentRow <= maxRow; currentRow++) {
			for (currentCol = minCol; currentCol <= maxCol; currentCol++) {
				if (currentRow != row || currentCol != col)
					numberOfLiveNeighbors += isAlive(currentRow, currentCol);
			}
		}
		return numberOfLiveNeighbors;
	}

	//sets cell to dead
	static void setToDead(int row, int col) {
		newOneDimensionalCheckerBoard[getIndex(row, col)] = 0;
	}

	//sets cell to alive
	static void setToAlive(int row, int col) {
		newOneDimensionalCheckerBoard[getIndex(row, col)] = 1;
	}

	//copies the new board to the current board
	static void copyNewBoardToCurrentBoard() {
		printf("copyNewBoardToCurrentBoard\n");
		int row = 0;
		int col = 0;
		for (row = 0; row < rows; row++) {
			for (col = 0; col < cols; col++) {
			currentOneDimensionalCheckerBoard[getIndex(row, col)] =
			newOneDimensionalCheckerBoard[getIndex(row, col)];
			}
		}
	}


	// NEW
	void processRow(int theRow)
	{
		printf("processRow entering identity (%d) with row %d.\n", identity, theRow);
		fflush(stdout);

		int row = theRow;
		int col = 0;
		int liveNeighbors = 0;

		for (col = 0; col < cols; col++) {
			liveNeighbors = countLiveNeighbors(row, col);

			if (1 == isAlive(row, col)) // cell started out alive
			{
				if (liveNeighbors < 2 || liveNeighbors > 3) {
					setToDead(row, col);
				}
			} else // cell started out dead
			{
				if (liveNeighbors == 3) {
					setToAlive(row, col);
				}
			}

			liveNeighbors = 0;
		}

		printf("processRow leaving identity (%d) with row %d.\n", identity, theRow);
				fflush(stdout);

	}


	void processRowsMPI(int startRow, int endRow)
	{
		int row = startRow;
		int col = 0;
		int liveNeighbors = 0;

		for (row = startRow; row <= endRow; row++)
		{

			printf("processRow identity (%d) with row %d.\n", identity, row);
			fflush(stdout);

			for (col = 0; col < cols; col++) {
				liveNeighbors = countLiveNeighbors(row, col);

				if (1 == isAlive(row, col)) // cell started out alive
				{
					if (liveNeighbors < 2 || liveNeighbors > 3) {
						setToDead(row, col);
					}
				} else // cell started out dead
				{
					if (liveNeighbors == 3) {
						setToAlive(row, col);
					}
				}

				liveNeighbors = 0;
			}
		}
	}


// NEW
	void liveLife() {

		int rowsPerProcessor = rows / (number_of_processes-1);

		printf("rowsPerProcessor %d.\n", rowsPerProcessor);
		fflush(stdout);

		int row = 0;
		int generation = 0;
		for (generation = 0; generation < generations; generation++) {
			//System.out.println("Generation: " + generation);
			printf("Generation: %d\n", generation);
			fflush(stdout);

			for (row=0; row < rows; row++) {


				printf("row %d \n", row);
				fflush(stdout);

				// We will have the first process send out each row
				// to be worked to the other processes.  The receiving
				// processes will do the work.
				if (0 == identity)
				{

					int sentRow = row;

					// The remainder will identify the processor
					// Example if rowsPerProcessor is 15 then
					// Row = 5:  5 / 15 = 0 so processor 0
					// Row = 14: 14 / 15 = 0 so processor 0
					// Row = 15: 15 / 15 = 1 so processor 1
					// Row = 17: 17 / 15 = 1 so processor is 1
					// Row = 60: 60 / 15 = 4 so processor is 4

					int processorIdentity = row / rowsPerProcessor;

					printf("MPI sending sentRow %d to processor %d\n", sentRow, processorIdentity+1);
					fflush(stdout);
					MPI_Send(&sentRow, 1, MPI_INT, processorIdentity, 0, MPI_COMM_WORLD);
				}
				else
				{

					int receivedRow = row;
					MPI_Recv(&receivedRow, 1, MPI_INT, 0, 0, MPI_COMM_WORLD,
					             MPI_STATUS_IGNORE);
					printf("Process %d received number %d \n",
							identity, receivedRow);
					fflush(stdout);
				}


			}


			if (0 == identity)
			{
				// Now that all processes have completed (MPI_Barrier)
				// We can update our current board and print it.
				copyNewBoardToCurrentBoard();
				//printOneDimensionalBoard(GameOfLife.currentOneDimensionalCheckerBoard);
				printOneDimensionalBoard(currentOneDimensionalCheckerBoard);
			}
		}
	}

	void liveLifeMPI() {

		int rowsPerProcessor = rows / number_of_processes;

		printf("rowsPerProcessor %d.\n", rowsPerProcessor);
		fflush(stdout);

		int row = 0;
		int generation = 0;
		for (generation = 0; generation < generations; generation++) {
			//System.out.println("Generation: " + generation);
			printf("Generation: %d\n", generation);
			fflush(stdout);

			for (row=0; row < rows; row++) {


				printf("row %d \n", row);
				fflush(stdout);

				// We will have the first process send out each row
				// to be worked to the other processes.  The receiving
				// processes will do the work.
				if (0 == identity)
				{

					int sentRow = row;

					// The remainder will identify the processor
					// Example if rowsPerProcessor is 15 then
					// Row = 5:  5 / 15 = 0 so processor 0
					// Row = 14: 14 / 15 = 0 so processor 0
					// Row = 15: 15 / 15 = 1 so processor 1
					// Row = 17: 17 / 15 = 1 so processor is 1
					// Row = 60: 60 / 15 = 4 so processor is 4

					int processorIdentity = row / rowsPerProcessor;

					printf("MPI sending sentRow %d to processor %d\n", sentRow, processorIdentity);
					fflush(stdout);
					MPI_Send(&sentRow, 1, MPI_INT, processorIdentity, 0, MPI_COMM_WORLD);
				}
				else
				{
					int receivedRow = row;
					MPI_Recv(&receivedRow, 1, MPI_INT, 0, 0, MPI_COMM_WORLD,
					             MPI_STATUS_IGNORE);
					printf("Process %d received number %d \n",
							identity, receivedRow);
					fflush(stdout);
				}
			}

			printf("******************* before copyNewBoardToCurrentBoard barrier");
			MPI_Barrier(MPI_COMM_WORLD);
			printf("******************* after copyNewBoardToCurrentBoard barrier");
			fflush(stdout);

			if (0 == identity)
			{
				// Now that all processes have completed (MPI_Barrier)
				// We can update our current board and print it.
				copyNewBoardToCurrentBoard();
				//printOneDimensionalBoard(GameOfLife.currentOneDimensionalCheckerBoard);
				printOneDimensionalBoard(currentOneDimensionalCheckerBoard);
			}
		}
	}

	//main
	int main(int argc, char *argv[]) {
		// MPI setup
		MPI_Init(&argc, &argv);

		MPI_Comm_size(MPI_COMM_WORLD, &number_of_processes);

		MPI_Comm_rank(MPI_COMM_WORLD, &identity);

printf("Identity (%d).\n", identity);
fflush(stdout);

		if (0 == identity)
		{

			printf("Number of processes (%d).\n", number_of_processes);
			fflush(stdout);

			// Read in the name of the configuration file from the command line
			configFileName = argv[1];

			printf("Config FileName: %s\n", argv[1]);
			fflush(stdout);

			loadConfiguration(configFileName);

			printOneDimensionalBoard(/*GameOfLife.*/currentOneDimensionalCheckerBoard);
		}

		// Wait for setup to have been done by process 0
		// before continuing
		printf("******************* before setup barrier %d\n", identity);
		MPI_Barrier(MPI_COMM_WORLD);
		printf("******************* after setup barrier %d\n", identity);
		fflush(stdout);

		/*GameOfLife.*/
		liveLife();

		if (0 == identity)
		{
			printf("**************************\n");
			printf("Game of Life Final State: \n");
			printOneDimensionalBoard(currentOneDimensionalCheckerBoard);
			printf("**************************\n");
			fflush(stdout);
		}


		// Wait for all processes to finish before finalizine
		printf("******************* before Finalizing barrier %d\n", identity);
		MPI_Barrier(MPI_COMM_WORLD);
		printf("******************* after Finalizing barrier %d\n", identity);
		fflush(stdout);


		// MPI cleanup
		MPI_Finalize();

		return EXIT_SUCCESS;
	}
