import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Bank {

	private Lock bankLock;
	private int numberOfAccounts;
	private int[] accountBalances;
	private Lock[] accountLocks;

	// constructor for bank
	// now we create a lock bank lock and put it into the constructor
	public Bank(int numOfAccounts, int startingBalance, Lock bLock) {
		numberOfAccounts = numOfAccounts;
		accountBalances = new int[numberOfAccounts];
		accountLocks = new Lock[numberOfAccounts];
		this.bankLock = bLock;
		for (int i = 0; i < numberOfAccounts; i++) {
			accountBalances[i] = startingBalance;
			this.accountLocks[i] = new ReentrantLock();
		}
		
	}

	// gets the balance of an account number
	public int getBalance(int accountNumber) {
		return accountBalances[accountNumber];
	}

	// withdraw method
	public void withdraw(int accountNumber, int amount) {
		
		accountBalances[accountNumber] -= amount;
		
	}

	// deposit method
	public void deposit(int accountNumber, int amount) {
		accountBalances[accountNumber] += amount;
	}

	// gets number of accounts
	public int getnumberOfAccounts() {
		return numberOfAccounts;
	}

	
	// locks the bank
	public void lockTheBank() {
		bankLock.lock();
	}

	// unlocks the bank
	public void unlockTheBank() {
		bankLock.unlock();
	}
	
	public void lockAccount(int account)
	{
		accountLocks[account].lock();
	}
	
	public void unlockAccount(int account)
	{
		accountLocks[account].unlock();
	}

}
