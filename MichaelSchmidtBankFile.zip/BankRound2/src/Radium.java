import java.util.*;

/**
 * Write a description of class VariablesClass here.
 * 
 * Peter Vicenzi 9/17/2014
 */
public class Radium {

	public static void main(String[] args) {

		Scanner LQ16 = new Scanner(System.in);
		int inputRadius;

		System.out.println("What is the radius?");
		inputRadius = LQ16.nextInt();
		System.out.println("inputradius");

		System.out.println("The diameter is " + (2 * inputRadius));
		System.out.println("The circumference is "
				+ (2 * Math.PI * inputRadius));
		System.out.println("The area is " + (Math.PI * inputRadius));
	}

}
