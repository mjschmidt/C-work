import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Application {
	// Driver Class
	public static void main(String[] args) {
		
		int numberOfClients = 1000;
		int numberOfBankAccounts = 10000;
		int numberOfIterations = 100000;
		int startingAccountBalance = 1000;
		Lock bankLock;
		
		bankLock = new ReentrantLock();
		//create a new bank and pass it variable bankLock
		Bank swissBank = new Bank(numberOfBankAccounts, startingAccountBalance, bankLock); 
		Client[] clientArray = new Client[numberOfClients];
		Auditor auditor = new Auditor(swissBank);
		
		//sets the auditor thread to a daemon thread
		auditor.setDaemon(true);
		//starts the auditor
		auditor.start();
		
		// objects of classes
		for(int i=0; i < numberOfClients; i++){
			clientArray[i]= new Client(swissBank, numberOfIterations);
		}
		
		for(int i=0; i < 1000; i++){
			clientArray[i].start();
		}
		
		//Client clientclass = new Client(swissBank, 1000);
		// run methods of auditor and client such that it checks accounts before
		// and after 1000 transfers
		//clientclass.run(); <- Don't need class to run anymore
		//auditor.run(); <-Don't need second auditor
		// V Test for one of the balances to make sure it was never over drawing
		// the accounts
		// System.out.println("the first account has " + StartingBalance[1]);
	}

}
