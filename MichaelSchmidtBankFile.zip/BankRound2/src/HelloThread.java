import java.util.Random;

public class HelloThread extends Thread {
	
	public void run(){
		System.out.println("hello from the thread");
		try{Thread.sleep(5000);
		}catch(InterruptedException e){
			   e.printStackTrace();
			}
		System.out.println("bye from the thread");
	}
	
	public static void main(String[] args) {
		HelloThread hello = new HelloThread();
		hello.start();
		Random r = new Random();
		r.nextInt(5);
		
		//hello.run();
	}	
}
