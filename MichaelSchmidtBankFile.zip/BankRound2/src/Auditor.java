

public class Auditor extends Thread{

	Bank bank;

	public Auditor(Bank b) {
		bank = b;
	}

	public void run() {
		
		int sumOfAccounts = 0;
		int overdrawnAccounts = 0;
		int balance;
		
		//locks the auditor before it checks the account balances then unlocks
		//the bank before it prints and sleeps
		while(true){
		for (int i = 0; i < bank.getnumberOfAccounts(); i++) {
			bank.lockAccount(i);
		}
		for (int i = 0; i < bank.getnumberOfAccounts(); i++) {
			balance = bank.getBalance(i);
			sumOfAccounts += balance;

			// if balance is less than zero, add to number overdrawn
			if (balance < 0)
				overdrawnAccounts++;
		}
		for (int i = 0; i < bank.getnumberOfAccounts(); i++) {
			bank.unlockAccount(i);
		}
		System.out.println("Bank balance: " + sumOfAccounts);
		System.out.println("Number of overdrawn accounts: " + overdrawnAccounts);
		try{
		
		Thread.sleep(1);
		}catch(InterruptedException e){
			   e.printStackTrace();
			}
		sumOfAccounts = 0;
		//overdrawnAccounts = 0;
		}
	}
}
