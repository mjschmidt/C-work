import java.util.Random;

public class Client extends Thread {

	public Bank bank;
	private int transfernumber;
	Random r = new Random();

	public Client(Bank b, int t) {
		transfernumber = t;
		bank = b;
	}

	// Run Method
	public void run() {
		int numberOfAccounts = bank.getnumberOfAccounts();
		int transferFromAccount;
		int transferToAccount;

		// Does x large number of transfers
		// locks the bank for one client at a time
		for (int i = 0; i < transfernumber; i++) {
			transferFromAccount = r.nextInt(numberOfAccounts);
			transferToAccount = r.nextInt(numberOfAccounts);
			
			// Locks the lower accounts that need to be locked for transaction
			if (transferFromAccount < transferToAccount){
				bank.lockAccount(transferFromAccount);
				bank.lockAccount(transferToAccount);
			}else{
				bank.lockAccount(transferToAccount);
				bank.lockAccount(transferFromAccount);
			}
			
			
			// System.out.println("Locking Account# " + transferFromAccount);
			
			// System.out.println("Locking Account# " + transferToAccount);

			// checks to make sure there is enough money to transfer, then
			// decides amount
			int accountBalance = bank.getBalance(transferFromAccount);
			if (accountBalance > 0) {
				int amount = r.nextInt(accountBalance);
				bank.withdraw(transferFromAccount, amount);
				bank.deposit(transferToAccount, amount);
				bank.unlockAccount(transferFromAccount);
				// System.out.println("Unlocking Account# " +
				// transferFromAccount);
				bank.unlockAccount(transferToAccount);
				// System.out.println("Unlocking Account# " +
				// transferFromAccount);
			}
		}

		// transfers using Bank class

	}
}