import java.util.concurrent.locks.Lock;
//This class is unused at the moment

public class Account extends Thread{
	
	public Bank bank;
	//private Lock accountLock;
	
	//public Account(Bank b, Lock aLock) {
		//bank = b;
		//this.accountLock = aLock;
	//}
	
	public void run(){
		
		
	}

}
