#include "xList.h"

#include <stdlib.h>

/* Start: Remove when implementation complete */
#include <stdio.h>

/* A macro for unimplemented functions */
#define UNIMPLEMENTED(msg) \
  fprintf(stderr, "xList: Unimplemented function %s\n", (msg));

/* End: Remove when implementation complete */

typedef struct xList_Element_ {
	struct xList_Element_ * next;
	void* data;
} xList_Element;

typedef struct xList_ {
	struct xList_Element_ * head;
	struct xList_Element_ * tail;
	unsigned int size;
} xList;

/* Create a list */
xList_Ptr xList_create() {
	xList_Ptr list = malloc(sizeof(struct xList_));
	list->head = NULL;
	list->tail = NULL;
	list->size = 0;
	return list;
}

/* Destroy a list */
void xList_destroy(xList_Ptr list) {

	uint32_t listSize = xList_size(list);

	int i;
	for (i = 0; i < listSize; i++) {
		xList_remove(list, NULL);
	}
	//UNIMPLEMENTED("xList_destroy");
}

/* Note: In inserting and removing elements from the list we're taking
 * it on faith  that element is an element of list  and not some other
 * xList.  Tracking the element down would be expensive.
 */

/* Insert a value after element, or at head of list if element is NULL */
void xList_insert(xList_Ptr list, xList_Element_Ptr element, void* data) {

	struct xList_Element_ * current;
	struct xList_Element_ * newElement;

	//malloc memory for new element
	newElement = malloc(sizeof(struct xList_Element_));
	newElement->next = NULL;
	//put data into newElement
	newElement->data = data;

	//if list is null, create an empty list
	if (list == NULL) {
		list = xList_create();
	}

	//if element is Null, put at beginning of the list
	if (element == NULL) {
		//if list is empty make head and tail newElement
		if (list->head == NULL) {
			list->head = newElement;
			list->tail = newElement;
		} else //insert new element at the head
		{
			newElement->next = list->head;
			list->head = newElement;
		}
	} else  //element is list->size not null
	{
		if (list->head == NULL) //
		{
			list->head = newElement;
			list->tail = newElement;
		} else  //
		{
			current = list->head;
			while (current != element) {
				current = current->next;
			}
			if (current->next != NULL) {
				newElement->next = current->next;
				current->next = newElement;
			} else {
				current->next = newElement;
				list->tail = newElement;
			}
		}
	}
	list->size++;
}

/* Remove the value after element, or at head of list if element is NULL */
void xList_remove(xList_Ptr list, xList_Element_Ptr element) {
	struct xList_Element_ * current;
	struct xList_Element_ * temp;

	if (element == NULL) {
		if (list->head != NULL) {
			current = list->head;
			list->head = list->head->next;
			current->next = NULL;
			free(current);
			list->size--;
		}
	} else {
		current = list->head;
		while (current != element && current != list->tail) {
			current = current->next;
		}

		temp = current->next;
		//if we found the element
		if (current != list->tail) {
			//if the next element is not the tail, point to the element two nexts away and free next
			if (current->next != list->tail) {
				current->next = current->next->next;
				temp->next = NULL;
				free(temp);
			} else //if the next thing is the tail make current tail, and point to null and free temp
			{
				current->next = NULL;
				list->tail = current;
				free(temp);
			}

			list->size--;
		}
	}
}

/* Determine the number of elements in the list */
uint32_t xList_size(xList_Ptr list) {
	return list->size;
}

/* Obtain the first element in the list */
xList_Element_Ptr xList_first(xList_Ptr list) {
	return list->head;
}

/* Obtain the last element in the list */
xList_Element_Ptr xList_last(xList_Ptr list) {
	return list->tail;
}

/* Obtain the data associated with the element */
void* xList_data(xList_Element_Ptr element) {
	return element->data;
}

/* Obtain the next element in the list */
xList_Element_Ptr xList_next(xList_Element_Ptr element) {

	return element->next;
}
